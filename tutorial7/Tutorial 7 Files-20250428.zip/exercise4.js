var superHero = {
    firstName: "Peter",
    lastName: "Parker",
    powers: [
        "Super Strength",
        "Wall climbing"
    ],
};

