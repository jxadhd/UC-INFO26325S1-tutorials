var aPerson = {
    name: "Elon Musk",
    age: 34,
    degrees: "Software Engineering, Computer Science, Commerce and Space Exploration"
};

console.log(aPerson);